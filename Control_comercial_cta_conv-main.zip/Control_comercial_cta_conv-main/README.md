# Control_comercial_cta_conv
Este proyecto es una herramienta de control comercial para asesores, orientada a evaluar el cumplimiento de objetivos mensuales, el mix de ventas y la calificación a comisiones, utilizando reglas reales del sector de telecomunicaciones. El sistema permite que cada asesor ingrese sus propias ventas y también configure manualmente los objetivos.
